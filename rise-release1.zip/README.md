# rise-foundation-kavi
RISE foundation - static website


Link back to Colorlib in footer can't be removed. Template is licensed under CC BY 3.0.
